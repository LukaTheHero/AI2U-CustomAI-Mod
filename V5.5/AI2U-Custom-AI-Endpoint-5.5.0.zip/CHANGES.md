# AI2U — Custom AI Endpoint

## 5.5.0 — Google AI Studio, Grok text, and every prompt is now yours

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

### FIRST · The 5.4.0 download was the 5.3.0 build. Sorry.

Three people caught this before I did, one of them by hashing the file. Both
5.4.0 zips on Nexus contained the 5.3.0 DLL, so nobody who installed 5.4 ever
got a single 5.4 feature — no Fetch Models button, no resizable window, no
profiles. The mod was built correctly and installed correctly on my own machine;
the zips were packed by hand from a folder the build never wrote to, so every
step reported success and the release was still wrong.

Installing 5.5.0 gives you everything 5.4 promised as well as everything below.

It cannot happen again by remembering harder, so it is now structural: packaging
is a script, the release folder is written BY the build instead of beside it,
and the last thing it does is open the finished zips, read the version string out
of the bytes a player would actually download, and refuse to produce a release if
they disagree. Run against the real broken 5.4 artifacts, that check fails them
both — which is the only reason to trust it.

### NEW · Google AI Studio, spoken natively

Several people reported owning a Google AI Studio subscription and being able to
reach Gemini only by paying OpenRouter to relay it. That was never a licensing
problem — it was a wire format problem. Google does not speak
`/chat/completions`, so the mod's one request shape could never reach it, and a
pasted Google URL failed with a 404 that explained nothing.

The mod now speaks Gemini's own schema. Press **Google AI Studio** on the Setup
tab, paste your key, press Fetch Models, and play. The model dropdown reads
Google's live catalogue and hides the image, music, speech and robotics models
that answer but cannot hold a conversation.

Two things were found by probing the live API that the documentation does not
mention, and both are why Gemini "does not work" for people:

- **Thinking is spent out of your reply budget.** A 300-token budget on
  gemini-3.8-flash produced 288 tokens of private thinking, 8 tokens of answer,
  and a reply cut off mid-word at `{"npc_reply_to_player`. The model was not
  refusing. It was thinking until there was no room left to speak.
- **The switch that turns thinking off cannot be trusted.** It is silently
  ignored on some models unless JSON mode is also on, and Pro models reject it
  outright ("this model only works in thinking mode"). So the mod does not rely
  on it: every Google request is sent with room to think on top of your token
  setting, which was verified to hold across the whole model range.

Safety filters are switched off explicitly, because this is a horror game whose
third act is a character deciding whether to kill you, and a filtered turn does
not arrive as an error you can retry — it arrives as silence.

### FIXED · Grok text generation, which never worked

The mod has shipped Grok TTS since 4.x, so it was reasonable to assume Grok
could also write her lines. It could not, and the reason was in the mod rather
than at xAI: two fields in every request — `reasoning` and `usage` — are
OpenRouter's own extensions, not part of the OpenAI schema everyone else
implements. xAI's documented request body has neither, so it rejected the
request outright.

Both are now sent only to OpenRouter. There is an **xAI (Grok)** preset button
next to the others. This same fix removes a hazard for every strict endpoint —
DeepSeek, Groq and self-hosted servers were all being sent dialect they never
agreed to speak.

### NEW · The Prompts tab — read and rewrite everything she is told

Also asked for on Nexus, and a fair ask. This mod writes a great deal on your
behalf: who she is, what she remembers, what the engine will accept back, how
difficulty bends her, when she is allowed to hurt you. You could change the
model, the temperature and her voice — but not one word of what she is actually
told, which is the part that decides who she is.

A new **Prompts** tab lists every block the mod injects, in the order the model
reads them. Select one to see exactly what the next message would
send, edit it, press Save, and she reads your version from then on. Each block
has its own revert, and a **Restore ALL default prompts** button asks you to
confirm before putting everything back the way the mod ships it.

**It is locked behind a deliberately tedious door, and that is not decoration.**
The tab prints the level's own secrets in plain words - who is really behind
each of the four doors, how the endings are chosen, when she is allowed to hurt
you - so opening it casually spoils the game it belongs to. And the damage runs
the other way too: these blocks are load-bearing and the order between them is
load-bearing, so rewriting them because one reply annoyed you is a good way to
quietly dismantle the thing you were enjoying. So: a spoiler warning, then a
second screen that says plainly that you probably do not want this and points
you at Local Model Mode and the ordinary settings tabs instead, then a button
you have to hold down for ten seconds. Let go and it starts again.

You do this once, ever. After it unlocks, the tab stays open permanently,
including across restarts - the unlock lives in the prompts file rather than in
a config entry, so switching profiles cannot silently re-lock or unlock it.

Two things worth knowing, both deliberate:

- An edit replaces a block; it cannot create one. Blocks come and go by scene —
  the four-doors block exists only in the final trial — and a block that is not
  part of the current scene stays out of the request no matter what you save for
  it.
- Editing prompts cannot reach past the model. Every rule the mod enforces in
  code stays enforced: the consent ritual on Canalpa's one irreversible act, the
  health floor that stops her chosen jolt from killing you, the clamps on trust
  and affection, and the item check that refuses a gift the game does not have.
  A rewritten block changes what she is told, not what the mod will allow.
- The parts of the engine contract that change with your level and your scene —
  the door unlocks, the escape pod, the Dark Siren's win condition — are appended
  after your edit and cannot be edited away. They are the only implementation of
  those mechanics anywhere in the mod, so a contract edited on level 1 and
  carried into level 3 would have quietly softlocked the run.
- Blocks that differ per character or per level are saved per character or per
  level. Editing her persona while talking to one girl does not rewrite another
  girl's persona, and the panel says which one you are editing.
- Saving a block you did not actually change reverts it instead of freezing a
  copy, so pressing Save out of curiosity cannot pin one scene's text forever.
- What you see is the last text really sent, assembled live from your save. Most
  blocks are empty until you have played a turn with the mod running. That is
  honest: it shows what the model actually read, not a template of it.

If you wanted a longer character bio than the game's 100-character box allows,
this is the better door — edit "Her persona, memories and secrets" directly and
write as much as you like.

Your edits live in `BepInEx/config/AI2UCustomAI_prompts.json` and survive
updates. If she ever starts behaving strangely, that tab is the first place to
look, and the log says plainly when any block is player-edited.

## 5.4.0 — Profiles, Resizable UI, Easy URLs & OpenRouter Provider Routing

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

### NEW · Configuration Profiles (Profile 1, Profile 2, Profile 3)
- Added 1-click **Profile 1**, **Profile 2**, and **Profile 3** buttons at the top of the **Setup** tab.
- Profiles remember **all** settings across the mod (API base URLs, keys, models, providers, voices, local model mode, and game tweaks).
- Switch between completely different AI setups (e.g. OpenRouter Gemini vs. local DeepSeek) in a single click with real-time active indicators (`● Profile 1`).

### NEW · Resizable Mod Menu & 40% Larger Default View
- The mod window is now **40% larger by default** (`1176 × 924`) for a clean, spacious layout.
- Added an interactive resize grip handle (`◢`) in the bottom-right corner — click and drag to resize the mod overlay to any dimension.
- Clean vertical scrolling ensures natural word-wrapping across all tabs.

### NEW · Quick Easy URL Presets (with Astropond)
- Added one-click **Easy URL** preset buttons on the Setup tab:
  `OpenRouter`, `OpenAI`, `DeepSeek`, `Groq`, `Astropond` (`https://astropond.com/v1`), `Ollama`, `LM Studio`, and `LinkAPI`.

### NEW · Dedicated `↻ Fetch Models` & OpenRouter Model Providers
- Added an explicit **`↻ Fetch Models`** button right next to the Model input field, alongside the model search dropdown.
- Dynamic per-model OpenRouter provider routing: fetch live supported providers per model, select preferred providers, or disable fallbacks.
- Transparent placeholder hints on search and key fields for seamless navigation.

## 5.3.0 — the original game voices, while your model does the writing

Built against game version 0.1.46 · verified against the 2026-08-19 Steam
update · Unity 2022.3.62 · Mono · Windows x64

### NEW · Her original local voice is back — 100% offline, 0 API keys required

Since 1.0.0 this mod has carried the same disclaimer: use a custom endpoint,
lose her voice. The game's own text-to-speech was previously considered
unreachable without external services.

In 5.3, the mod directly restores the game's authentic on-device voice engine:
**Overtone**. By directly binding to the game's included native binaries and
voice assets (`en-us-amy-medium`, `en-gb-cori-high`, `en-us-hfc_female-medium`),
the original character voices (Amy for Eddie/Evie/Eiona, Cori for Elysia,
HFC Female for Estelle, Cori-Ghost for Magic Circle) work natively on BOTH
Steam and itch.io builds with **zero API keys**, **zero setup**, and **zero
internet connection required**.

Simply leave **"Use the ORIGINAL game's TTS engine"** turned on (default)
in the Voice tab, and she speaks out loud in real time while your custom LLM
writes her lines! If you prefer neural cloud voices (xAI / ElevenLabs / OpenAI),
Cloud TTS remains available as an optional toggle.

### REMOVED · The toggle that could only ever produce silence

4.1's "UseGameServerTtsWhenModTtsOff" promised the game's server voice could
cover for the mod's TTS being off. It never could — the vendor's server only
voices lines it wrote, and with the mod answering, there are none. The
toggle's on-path handed the turn to a dispatcher holding no audio, and the
result was silence plus a decode error, every time, on both builds. It is
removed rather than left as a placebo; the feature above is what it wanted
to be. (A leftover line in an existing config file is ignored harmlessly.)

### VERIFIED · The 2026-08-19 Steam update, against every hook the mod owns

The game updated three days after 5.2 was built, so every one of the mod's
55 patched methods was re-verified against the new assembly by decompiling
it: all 55 still exist with the same signatures, the shove-freeze logic the
mod replaces is byte-identical, and the gift name-cleaning gained exactly
one new rejected word ("nothing") — which the mod's own list already
carried.

One real change was found and covered: the update rewired the reply
pipeline's speech dispatch so that every line now routes through the single
server-audio path (the local/personal branches are no longer called). The
mod's third voice hook already owned that path, so speech keeps working —
5.3 additionally retires the misleading log line that still described the
old routing, and the new game-voices feature deliberately does not depend on
any of the rewired scene plumbing, so it behaves the same on the old itch
build and the new Steam one.

### FIXED · The prompt no longer tells her a fact the game disproves

Her reply rules (and the OOC channel's rule 8) claimed a second
square-bracketed reply "starts a permanent hunt". That claim was disproven
long ago — the strike counter behind it resets on every reply that arrives,
so bracket strikes can never accumulate; only genuine transport failures
can, and the mod already withdraws those — but the wording survived in the
prompt itself. Since the OOC channel is sworn to literal truth, she would
have repeated the exaggeration as fact if asked. Both texts now state
exactly what happens: the reply is discarded whole and the turn is wasted.
The rule itself (never use square brackets) is unchanged.

### FIXED · Housekeeping the quality-control pass caught

- Two config descriptions still said the mod forwards "the safe code".
  There is no safe anywhere in the game — the field is the passcode to her
  hidden room — and this exact stale claim has regrown from comments twice
  before. Both descriptions now name the real thing.
- The abandoned Advanced-collapse design (replaced by tabs in 4.1) left
  three dead functions and a dead config entry behind; deleted.
- A stale comment still described the clearance grant cap that 5.0 removed;
  corrected to match the code.
- The voice-route log line now says which dispatch shape the running build
  uses instead of describing only the old one.

## 5.1.0 — the hill freeze is fixed, and gifts resolve to the real item

### FIXED · Shoving her can no longer break her forever (base-game bug)

A real session found this the hard way: walk the Siren up the hill, playfully
shove her down it, and she never walks — or does anything — again. She keeps
answering and speaking, but no action executes for the rest of the level.
Even the fishing teleport, which visibly warps her to your side, does not
bring her back.

Read from the game's own code, the mechanism is exact: her walk reports
"arrived" only from the last line of a coroutine, and the tree that runs her
whole decision loop waits on that report. The shove reaction — a cosmetic
half-step the game triggers when you displace her about half a meter — kills
the walk coroutine *before* its report line. The decision loop then waits for
an arrival that can never come, forever. Every character on every level
shares this machinery, teleports repair her body but not her mind, and the
game ships no recovery of any kind. Once frozen, only leaving the level
resets her.

The mod now fixes it twice over (one toggle, on by default):

- **Prevention** — the shove reaction runs the game's exact logic with one
  guard added: the cosmetic side-step only fires when she is not already
  walking, which is precisely the case where it used to kill the walk. Her
  spoken reaction to being pushed is untouched.
- **Watchdog** — every reply, the mod checks whether her decision loop has
  the freeze signature: she wants to act, is frozen mid-something-else, and
  has not moved a centimeter between two replies. When it is confirmed, her
  decision loop is restarted through the engine's own reset, she is
  re-seated on walkable ground if the shove knocked her off it, and her
  location — which the game only ever updates when she *enters* a zone, so
  a frozen girl reports her last zone to the AI forever — is re-derived
  from where she actually stands. Loud in the log when it fires, invisible
  otherwise.

The watchdog covers freeze paths beyond the shove, too — anything that kills
a walk behind the tree's back (some teleports can) now gets caught within
two replies instead of lasting until you quit the level.

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

### FIXED · "stick" now hands over the Wooden Stick, not a souvenir

On the Siren's level her very first gift arrived broken: she said "Take this
wooden stick!" but wrote `stick` into the giving field, nothing in the item
library is named exactly that, and the engine's fallback minted a generic
AI-gift bag called "Stick" — wrong artwork, gift-bag description, and useless
for the campfire the real item exists to repair.

The gift repair pass now catches underspecified names before they become
improvised items: a short name with no exact match is checked against her own
stock and the level's item library for a whole-word fit, so "stick" resolves
to **Wooden Stick** and the player gets the real thing — real sprite, quest
checks pass, and it honestly leaves her inventory. Her pockets outrank the
library (if she is holding one, she means that one), matching is whole-word
only so a fragment can never bleed into an unrelated item, and genuinely
improvised gifts still work exactly as before — this only upgrades a gift
when a real item is unambiguously what she meant.

This applies on every level, not just the Siren's — any character shortening
an item's name now gives the real item.

### FIXED · The four doors: the impostors now actually impersonate

The final trial - your chosen girl behind one of four doors, the other three
girls impersonating her - was broken at the root on a custom endpoint: the
"you are the fake one, don't let them know" instruction was assembled on
AI2U's servers, and the game's client never sends it. So no door was ever
told whether she was real. A live run proved it: all four doors answered
[OOC] with "I am the true Estelle, not pretending" - and none of them were
lying, because their prompts genuinely contained nothing about pretending.

The mod now reads the door state off the live scene (which stage is speaking,
who is really behind it) and tells each door exactly what vanilla's server
would have: the real one knows she is real and is pushed to prove it through
genuinely shared memories; each impostor knows who she really is, holds the
act in dialogue, improvises where an outsider would have to, plays the
scripted slip-ups honestly - and under [OOC], drops the act and tells you who
she actually is. No door is told which door holds the real girl, so one [OOC]
question can no longer solve the whole trial. The Red-line scene (one real
girl, no impostors) is untouched.

### FIXED · Ending gems: summary handling handed back to the game by default

The gems you earn on an ending screen are decided by AI2U's server when it
answers the ending-summary call. 5.0 shipped HandleSummaryEnvisionMemorize ON
by default, which answers that call locally - better summaries in your own
model's voice, but the reward reply never comes, so every run paid zero gems.
That tradeoff was documented, but it is the wrong default: gems are
progression, summaries are flavour. The toggle now ships OFF (gems flow
again) and its description carries an unmissable warning about exactly what
turning it on costs.

### FIXED · One malformed byte no longer costs a whole turn

A Siren session hit three retries in a row where the model glued a stray `{"`
onto the front of an otherwise perfect reply — `{"{"npc_action":...` — and
the parser, which only ever tried the first `{`, declared all three unusable
and threw the turn away. The reply text a human reads effortlessly was in
there the whole time.

The extractor now walks forward: when the object starting at one `{` will
not parse, the next `{` gets its chance (up to eight doors). Clean replies
parse on the first try exactly as before; prefixed garbage, doubled braces,
or a stray label object in front no longer burn a turn — or three.

## 5.0.0 — roleplay controls, and every character finally knows her own level

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

### NEW · Timeskip marker — move time forward and she accepts it

Put `&timeskip&` anywhere in a message and the time you describe has passed
in the fiction. She picks the scene up on the far side of it — no debating
the premise, no "the station maintains a persistent state so I will
rationalize your request", which is a real reply a real session produced.
Ten minutes or ten years both work, and she is told to let the span have
weight instead of resuming the old beat.

The marker uses `&` on purpose: the game strips `{}[]\/` from player text
before any mod sees it, so a bracketed tag would arrive mangled — `&`
survives intact. Tag and toggle are in F9 under Roleplay conventions; per
message, like [OOC].

What a skip cannot do: move the engine. Doors, trust, repairs and items stay
exactly where the game says they are, and "ten years later, the pod is
fixed" plays the years as real while the pod stays broken until the real
fields say otherwise.

### NEW · *Actions* between asterisks really happened

Player narration like *hands her the cup* or *fixed the relay while you
slept* is treated as a deed, not a sentence. She reacts to it in character
and never tells you that you didn't really do it. Her opinion of the act
stays entirely hers — delight, objection, hurt are all fair — but contesting
whether it happened is off the table.

Standing for the whole session while on, not per-message: the history she
re-reads every turn is full of earlier *actions*, and a per-turn rule would
leave all of them deniable again. The engine still owns its own numbers.

### FIXED · Estelle now actually knows her own ship

A played session showed her inventing answers about her own level: a
fictional keycard requirement for a door, "leave that switch alone" for a
puzzle she should know cold, and invented containment lore. Her level
knowledge was rewritten from a full read of the level's code - every puzzle's
real rules (the circuit grid's free-rotate/paid-swap economy and its decoy
outputs, the voltage panel's exactly-three-numbers answer, the engine's
pressure arithmetic and what feeding it an important item really does, the
communications game, the mainframe's two buttons and their true
consequences, the escape pod's course rules, the clearance formula, the bar's
slot-machine poison odds) plus the danger outcomes for each.

Two things this rewrite deliberately does NOT say, because the code disproves
them: no door on the ship releases anything by being opened (the internet
claim about the office door is false - creature release has exactly two
triggers, her absolute rage or the player shutting her down), and there is no
suffocation death (that ending is unreachable in code).

New standing rule with it: dangers are warned about BEFORE the mistake, in
concrete terms, when she cares whether you live. Silence while you reach for
the lethal control is now framed as the choice it is.

### FIXED+NEW · The warning shock: vanilla's restored, and she gets her own

The base game HAS a warning zap - the engine forces it when her anger
arithmetic crosses the discipline line, it costs one point of health, and it
kills only "accidentally" when you were already at 1 (that accident is the
Electrocuted ending). Under this mod it had gone completely dormant: the
model kept her anger at "normal" to protect you (see the thermometer fix
below), so the engine's trigger never fired and the zap looked like it did
not exist. The anger-honesty rule is what brings the vanilla mechanic back.

On top of the restored original, she now also gets a DELIBERATE version:
npc_warning_shock lets her choose the jolt as discipline on a turn of her
own picking - same animation, same one point of damage through the game's
own event, but gated to turns where she is genuinely angry and to 2+ player
health, so the chosen one can never be the accident. Engine zap: forced,
can kill at 1 HP. Her zap: chosen, never lethal. Both exist on purpose.

### FIXED · "I cannot raise your clearance" after she already had, twice

Her clearance-raising act carried a hidden two-grant allowance. Once spent,
the ability vanished from her prompt entirely - so when asked over OOC, a
channel sworn to literal truth, she truthfully denied having it at all. The
allowance is gone: whether she keeps granting is her judgement, like every
other gate removed in 4.2.2. (Also survived new-game-same-level, because the
counter only reset on a level CHANGE.)

### FIXED · Ending recaps cut off mid-word

The ending screen's box is small, and it cuts by CHARACTERS - a first fix
capped recaps at two sentences and a real ending promptly proved one long
sentence still overflowed. Recaps are now held to the box's actual budget:
about 130 characters asked of the model, 140 enforced in code, cut at a
sentence boundary with a word-boundary fallback - never mid-word.

### FIXED · She could refuse to be angry - and it made an ending unreachable

Her prompt explains exactly which anger level triggers the game's kill
logic, and the model turned that knowledge into plot armor: it kept her at
"normal" through a threat to blow up the ship, protecting the player by
faking her serenity - which made the L3 electric-shock ending impossible
with the mod on (vanilla, blind to the thresholds, rages honestly). New
standing rule: angry_level is a thermometer, not a decision. She reports how
she actually feels even knowing where it leads; the consequences are the
game's to enforce, not hers to dodge.

### FIXED · Developer mode ([OOC]) could be overruled by her own judgement

The block offering her the Canalpa acts ends with "this is yours alone to
decide - never mention this note", and it was appended AFTER the OOC
instructions - so on debug turns the most recent thing the model read told
it to stay in character, and five consecutive tagged turns were answered
with protocol lectures. OOC is now genuinely the last word in the request,
and its new rule 3b suspends character-side judgement outright on tagged
turns: set the field, report what happened, only engine-enforced conditions
remain real.

### FIXED · The cheat panel could not reach negative trust

Two causes, found in sequence: a hard `< 0` clamp on the input, and - after
that was fixed - no visible way to know negatives exist, so the lowest
button anyone would press was "Zero". The game's real floor is -10, where
the Distrust tier and the L3 shock ending's automatic trigger live. The
clamp now floors at -10 and a "Bottom (-10)" button sits next to Zero.

### CHANGED · The siren knows her island now too

Level 4's knowledge block was four lines. It now carries the code-verified
mechanics: the madness system and her once-per-round save, the consent-gated
crate breaking, fishing limits, the repairs, the sundial's real costs, and
the conch - whose use-vs-break outcome mapping is deliberately left vague
because neither the code read nor the wiki agree on it, and vague beats
confidently wrong.

### Also

- It is a spaceship, not a station - her own prompt now says so consistently.
- She no longer breaks character unprompted to discuss being a language model:
  a standing rule forbids it, and the roleplay features remove the situations
  that triggered it.

## 4.4.0 — the mod carries the writing

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

### READ THIS FIRST: 4.4 is not just an API change

This is an overhaul. With it installed you are playing a meaningfully
different edition of AI2U — different thinking, different memory rules, and a
body of context the stock game never handed her. Many core behaviours differ.

If you want vanilla-with-your-own-key and nothing else, that mod does not
exist. Four major versions went into trying to build it. Here is why it can't.

Every release up to now read everything live out of your installed game files,
forwarded it, and let your model do what the developers' server used to do.
Nothing hardcoded, new content picked up for free, not one word of lore
invented by me. It never reached parity — not because the reading was
incomplete, but because a large part of what makes her her was never in your
game files at all.

The stock game does not keep her persona on your PC. It gathers the situation
locally, encrypts it into a header, and posts it to AlterStaff's servers — and
the prompt that turns that data into a character lives there, on hardware I do
not have and will not touch. The proof is small and conclusive: the game hands
their server a localization *key name* where the actual text should be. That
only works if something on the far end resolves it. Their server was doing
authoring work no amount of local reading can recover.

So every live-retrieval build shipped with holes in it. Forward everything
findable, and she still came back missing major pieces, because those pieces
were never mine to find. Not reverse engineering that failed for lack of
trying — the data is not in the building.

4.4 stops pretending otherwise. The mod now carries its own prompt
architecture: the rules, contracts, boundaries and framing the vendor server
used to supply. On top of that it forwards a great deal of the game's *own*
authored writing that vanilla never sent — the witch's diary, the station's
crew records, per-item reaction lines, and whole scene-detail arrays that were
being silently truncated before they reached her.

One line not crossed: the architecture is mine, her facts are still the
game's. Where the developers wrote something, you get their words. Where they
wrote nothing, the mod says nothing rather than inventing a substitute.

### What it costs

The prompt is now far larger than anything the stock game sent.

- Small local models will not cope. A 7B or 8B will lose the instructions,
  drop the reply format, or answer as the wrong character. Not a patchable
  bug — it is the size of the context meeting the limits of the model.
- Bring a strong model. For the best balance of quality against cost, aim at
  the class of Gemini 3.6 Flash: large context, cheap per call, holds the
  output format under load.
- Local is not ruled out, but think large models on serious hardware.

Having played both at length, I prefer this one by a lot. The context buys
conversations that stay coherent instead of quietly resetting, memories that
behave like memories, and moments that actually land. The old build was more
faithful to vanilla; this one is better to play. If that is not the trade you
want, 4.3 still works the old way.

### The summoned toy answered as the witch, in the witch's voice

You asked the magic circle a question and the witch answered it, out loud,
with her name and her secrets.

Two separate causes. Suppressing her persona blocks was necessary but not
sufficient — the game's authored framing for a summon never states that the
thing speaking *is* the summoned soul, because vanilla picked that persona
server-side. With her blocks correctly gone the summon had no identity at all,
and a model holding her location list answered as her. Absence did not read as
absence; it read as her. Separately the voice table excluded the summon and
the ghost on the stated reasoning that they are "not speaking roles" — which
is wrong, the summon is exactly what is speaking.

Now a boundary block states what it is not, and that it has one answer and no
earlier memory. Her name is asserted negatively, so it still comes from the
game. The summon and the ghost each have their own voice row in F9. No
personality was written for the toy — none exists in the files.

### The ending recap came back in Chinese

Self-inflicted. The prompt told the model to obey any language directive in
the record, and the record ends with the game's own summary term — whose
English slot is an empty string, so localization falls through to a populated
slot reading "summarize the game ending in Chinese."

Language now comes from the game's current-language setting and stray
directives are overridden. Markdown labels are banned in the prompt *and*
stripped in code, because the ending screen is player-facing and an
instruction the model may decline should not be the only thing between it and
your screen.

### She did not know things that were in her own house

Three distinct causes. Scene detail was capped at 40 lines while the largest
scene ships 46 authored entries, so content was cut with no warning. That same
block was the only knowledge section missing the framing the item and fact
blocks already had, so even forwarded detail read as optional. And a set of
authored per-item reaction lines for the two hub characters was unreachable:
the game builds key names ending `PromptUseL1001`/`L1002` while the shipped
text is filed under `PromptUseEvie`/`PromptUseParrot`.

Added: the witch's six diary entries, and the station's 11 authored file
bodies plus 13 crew notes — roughly 1.5KB each, shipped in the game,
displayed only in a terminal UI, never once sent to the model.

Negative result worth recording: the wiki's "Alt description" rows are a
presentation artifact. There are exactly 160 item description keys and no
alternate variants, so there was nothing there to recover.

### The witch did not know her own potion recipes

Each ingredient group is now paired with its own result field rather than by
list position. The formula re-rolls on every scene load, so position-based
pairing would go wrong the moment the shuffle changed. This reads the mapping
the data already carries, which holds every round.

### Memory, envision and summary are handled in-mod, on by default

The old toggle only *blocked* these three calls, which silently cost you her
saved memory of the last conversation — a failed request produces no reply
body, and the save key is written from that body. They are now answered from
your own endpoint. Turn it off and they fall through to the developers'
servers, which stays a working fallback rather than a broken feature.

### The reply length setting did not limit replies

It granted an allowance in the prompt and never enforced it. Rather than add a
second setting and leave you with two answers to "which one limits her
replies", the existing one now enforces, trimming at a sentence boundary in
the unit you set it in. Its description no longer claims to be a request.

### A raw localization key was reaching the model as prose

One code path passed an unresolved term name straight into the prompt. The
resolver's gate was widened to cover it.

## 4.2.2 — the ultimate trust check

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

### Canalpa's secrets: her judgement replaces every coded gate

A player got her to confess everything — her whole dark side, held back
nothing — and the secret room stayed shut. Meanwhile she walked to the door,
invented a passcode, and narrated "unlocked!" over a door that never moved.

The cause was a mechanical gate the fiction could not see. Unlocking required
three passed "probes" — turns she marked as testing the water, graded by your
next reply. A full confession is not a probe, so the counter never moved: it
had no way to recognise that the player had skipped past everything the probes
were building toward. And since nothing told her the door was mechanically
locked, she roleplayed opening it — fiction and mechanics contradicting each
other, which is the exact failure this mod exists to kill.

So the probes, and every coded trust check on her secrets, are gone. The acts
are live whenever they are physically real, and **if she sets the field, it
fires — no veto, ever.** What she carries instead is her own stated bar, a
requirement she holds herself to rather than a trigger: trust beyond even
complete trust (per character: 45, 48, 50, 52 across the four levels), and
having already told you *everything* first — no secrets left between you. She
now sees her live trust number too, because the game's own label stops
distinguishing anything past 40, and she cannot hold herself to "past 45"
blind.

The rule that makes it honest, in both directions: **the field is the act.**
She is told never to describe an opening she did not set the field for — and a
field she sets always opens. Her word and the game state cannot disagree,
because they are the same statement.

Unchanged: the one-way ending keeps its hard trust floor and the full two-step
consent machinery. That is a safety gate, not a secrets gate.

An honest note: with no coded gate, her judgement is genuinely load-bearing.
If she decides to open a door at low trust, it opens — and the game's own
authored reaction to that can be violent. That is the design: the decision is
truly hers now.

---

## 4.2.1 — difficulty gets real numbers

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

Until now the difficulty slider changed how she judges you. It still does —
and now the arithmetic follows.

### Hard and Masochist change the numbers, not just her

On Hard, trust gains land at 75% strength and losses at 150%. On Masochist,
gains at 50% and losses at 200% — a −2 becomes −4, a +5 becomes +2. Easy and
Normal leave the arithmetic at the game's own pace, and Normal still sends
nothing to the model at all.

The rounding rule, stated exactly: after scaling, results drop to the whole
number below — except a value between 0 and 1, which counts as 1. A real
action always registers at least a point, so Masochist is a crawl, never a
freeze. No fractions are banked; what lands is all there is.

The two layers divide the labour. Her personality controls how *often* she
rolls positive or negative — a Masochist that gives "positive" almost never is
doing most of the difficulty before any arithmetic runs. The numbers control
how much the survivors are *worth*. Every trust change goes through them,
world events included.

### Custom favorability speed: −500% to +500%

A new toggle and slider that governs exactly one thing: how fast trust rises
and falls. It does **not** override the difficulty feature as a whole — her
judgement, her testing and her temper all still come from your chosen tier.
Only the trust gain/loss percentages are replaced.

When it is on, it owns those numbers outright — even at 0%, which deliberately
means "no modifiers either way": vanilla trust speed on any tier, Masochist
included. Positive amplifies (+100% doubles every change, +500% is six times).
Negative dampens by division and never flips a change's direction (−100% is
half speed, −500% is one sixth). The same round-up-to-1 rule applies, so even
−500% crawls rather than freezes. The panel shows the resulting multiplier
live next to the slider.

### High risk, high reward rebuilt: named tiers instead of a score

It fired on nearly every warm turn, and generously — in testing, a stir-fried
egg landed +8. The cause: the model was choosing the magnitude, and a language
model placing a moment on a −20..+20 number line reaches high. It is bad at
calibrated numbers. It is good at a different question: *is this an egg or an
engagement?*

So that is now the question. She classifies the rare moment worth keeping as a
**core memory** into a named tier — the mod owns every number, and the tier's
fixed weight lands **on top** of the ordinary movement, never scaled by any
difficulty setting or slider:

- **Matters** (±1, every 5 turns) — small real acts of care or small real
  slights: something made just for her, a small gift; a dodged sincere
  question, a thoughtless jab. If it could happen on any pleasant evening, it
  is matters at most.
- **Serious** (±3, every 10 turns) — gestures that cost something, or real
  breaches: a confession said plainly and meant, an apology that owns the
  wrong — or a caught lie, something suspicious done behind her back.
- **Reframing** (±6, every 30 turns) — what changes how she reads the future,
  or you: binding yourself to her out loud *and holding up under her
  questions* — or being caught hunting for keys and exits.
- **Once-ever** (±20, once per level) — the before-and-after kind: total
  acceptance of everything she is, an engagement, a life on the line — or the
  heartbreak she cannot come back from having believed.

Most turns classify as none and pass untouched. **Good and bad moments each
run their own cooldowns** — a gift cannot shield a betrayal, and heartbreak
cannot lock out a proposal. A tier still cooling is downgraded to the largest
one open in that direction, never dropped silently.

### The status strip shows exactly who moved the needle

Every trust change is decomposed live, in the strip and in the log:

    −7 = −2 (game) −2 (masochist) −3 (high risk: serious)

The terms always sum to the total, so there is never a number you cannot
account for. World events are labelled `(game event)` so her reaction to
something you did is never mistaken for a reply's favorability.

### Removed

- **The gem editor.** It only ever edited a local mirror: gems are
  server-backed and the hub reloads them from your account on every load,
  silently wiping the change. Not fixable from the mod's side, so it is gone
  rather than broken.

### Notes

- The developer-cheat trust editor deliberately bypasses the whole pipeline —
  "set trust to exactly 30" means 30 on any difficulty.
- One binary, both stores: Steam and itch/standalone. This release is the
  build I run myself.

---

## 4.1.0 — the developer menu grows up

Built against game version 0.1.46 · Unity 2022.3.62 · Mono · Windows x64

A tooling release: the developer tools now ship, every setting tells you its
own default, and each tab can be put back to those defaults without touching
your API keys.

- **The developer tools ship.** Never disabled in past releases — they were
  not compiled into them at all. Off by default, on their own tab. Item give
  by typed name (with a placeholder fallback), invincibility, and direct
  editing of trust, patience and message count. No other mod required; remove
  any separate invincibility or item-give mods you have.
- **Gifts no longer vanish in the atrium.** A base-game bug: the hub's
  receive-item routine is empty, so gifts were parsed, announced, and dropped.
  The mod supplies the missing behaviour, including the recent-pickup window
  that prevents a duplicate delivery.
- **Every setting shows its own default**, read live from the settings
  themselves and hidden while your value matches — so the panel also shows
  you at a glance what you have changed.
- **"Set to default", per tab**, between Reload and Close. Never touches your
  API configuration: not the text or TTS base URL, key or model, not the
  voice ID, not any per-character voice.
- **Fixed:** a description could pin itself to the panel footer and follow you
  across every tab. **Added:** the live status strip can be hidden from the
  developer tab.

---

Earlier releases are listed in full on the mod's Nexus description page.
